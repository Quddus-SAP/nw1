sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("qubabynw1.controller.App", {
        onInit() {
        }
      });
    }
  );
  